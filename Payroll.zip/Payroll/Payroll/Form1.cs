﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Payroll;
using MainClassLibrary;

namespace Payroll
{
    public partial class Form1 : Form
    {


       
        public static List<MainClass> empList = new List<MainClass>();
        public Form1()
        {
            InitializeComponent();
        }

        private void txtStudentID_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtStudentID.Text))
            {
                MessageBox.Show(txtStudentID, "Required Employee ID!");
            }
            Int32 x = 0;
            Int32.TryParse(txtStudentID.Text, out x);
            if (x <= 0)
            {
                MessageBox.Show("Employee ID Must be more than Zero");
            }
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox4.Text))
            {
                MessageBox.Show(textBox4, "Required Student ID!");
            }
        }

        private void textBox15_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox15.Text))
            {
                MessageBox.Show(textBox15, "Required Employee Email!");
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox1.Text))
            {
                MessageBox.Show(textBox1, "Required Employee Last Name!");
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            w4 df = new w4();

            df.ShowDialog();
        }
    }
}
