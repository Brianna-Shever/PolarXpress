﻿namespace Payroll
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblStudentG = new System.Windows.Forms.Label();
            this.btnEmp = new System.Windows.Forms.Button();
            this.btnLogin = new System.Windows.Forms.Button();
            this.btnPayment = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnReport = new System.Windows.Forms.Button();
            this.btnW2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblStudentG
            // 
            this.lblStudentG.AutoSize = true;
            this.lblStudentG.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStudentG.Location = new System.Drawing.Point(182, 31);
            this.lblStudentG.Name = "lblStudentG";
            this.lblStudentG.Size = new System.Drawing.Size(140, 29);
            this.lblStudentG.TabIndex = 107;
            this.lblStudentG.Text = "Main Menu";
            // 
            // btnEmp
            // 
            this.btnEmp.Location = new System.Drawing.Point(275, 145);
            this.btnEmp.Name = "btnEmp";
            this.btnEmp.Size = new System.Drawing.Size(219, 46);
            this.btnEmp.TabIndex = 143;
            this.btnEmp.Text = "Employee";
            this.btnEmp.UseVisualStyleBackColor = true;
            this.btnEmp.Click += new System.EventHandler(this.btnEmp_Click);
            // 
            // btnLogin
            // 
            this.btnLogin.Location = new System.Drawing.Point(50, 145);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Size = new System.Drawing.Size(219, 46);
            this.btnLogin.TabIndex = 144;
            this.btnLogin.Text = "Login and out";
            this.btnLogin.UseVisualStyleBackColor = true;
            this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click);
            // 
            // btnPayment
            // 
            this.btnPayment.Location = new System.Drawing.Point(50, 196);
            this.btnPayment.Name = "btnPayment";
            this.btnPayment.Size = new System.Drawing.Size(219, 46);
            this.btnPayment.TabIndex = 145;
            this.btnPayment.Text = "Payment";
            this.btnPayment.UseVisualStyleBackColor = true;
            this.btnPayment.Click += new System.EventHandler(this.btnPayment_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(50, 312);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(444, 46);
            this.btnExit.TabIndex = 147;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnReport
            // 
            this.btnReport.Location = new System.Drawing.Point(275, 197);
            this.btnReport.Name = "btnReport";
            this.btnReport.Size = new System.Drawing.Size(219, 46);
            this.btnReport.TabIndex = 149;
            this.btnReport.Text = "Report";
            this.btnReport.UseVisualStyleBackColor = true;
            // 
            // btnW2
            // 
            this.btnW2.Location = new System.Drawing.Point(50, 248);
            this.btnW2.Name = "btnW2";
            this.btnW2.Size = new System.Drawing.Size(444, 46);
            this.btnW2.TabIndex = 150;
            this.btnW2.Text = "Print  W-2 Form";
            this.btnW2.UseVisualStyleBackColor = true;
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Payroll.Properties.Resources.polarxpress;
            this.ClientSize = new System.Drawing.Size(555, 409);
            this.Controls.Add(this.btnW2);
            this.Controls.Add(this.btnReport);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnPayment);
            this.Controls.Add(this.btnLogin);
            this.Controls.Add(this.btnEmp);
            this.Controls.Add(this.lblStudentG);
            this.Name = "Main";
            this.Text = "Main";
            this.Load += new System.EventHandler(this.Main_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblStudentG;
        private System.Windows.Forms.Button btnEmp;
        private System.Windows.Forms.Button btnLogin;
        private System.Windows.Forms.Button btnPayment;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnReport;
        private System.Windows.Forms.Button btnW2;
    }
}