﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Payroll
{
    //MainClass class must be marked as Serializable
    [Serializable]
    public static class MainClass : IComparable
    {
        public int id { get; set; }
        public string fName { get; set; }
        public string lName { get; set; }
        public string address { get; set; }
        public string city { get; set; }
        public string state { get; set; }
        public string zip { get; set; }
        public dateTime birthDate { get; set; }
        public string homePhone { get; set; }
        public string cellPhone { get; set; }
        public string email { get; set; }
        public string hourlyPay { get; set; }
        public string SSN { get; set; }
        public int accountNumber { get; set; }
        public string bankName { get; set; }
        public string bankRouting { get; set; }
        public dateTime checkin { get; set; }
        public dateTime checkout { get; set; }
        public double payment { get; set; }
        public double paymentDate { get; set; }
        public double totalHours { get; set; }
        public double tax { get; set; }
        public MainClass()
        {
            id = 1;
            fName = "Alsaddig";
            lName = "Ibrahim";
            address = "2020 main st";
            city = "iowa City";
            state = "IA";
            zip = "52246-6352";
            birthDate.ToString = "mm/dd/yyyy";
            homePhone = "9118556323";
            cellPhone = "6418888666";
            email = "alsaddig@gmail.com";
            hourlyPay = 10.00;
            SSN = "958956321";
            accountNumber = 1234;
            bankName = "USA";
            bankRouting = "12345678";
        }
        public MainClass(int id, string fn, string ln, string address, string city, string state, string zip, DateTime bDate, string hPhone, string cPhone, string email, double hourpay, string ssn, int acc, string bankName, int routing)
        {
            id = id;
            fName = fn;
            lName = ln;
            address = address;
            city = city;
            state = state;
            zip = zip;
            birthDate = bDate;
            homePhone = hPhone;
            cellPhone = cPhone;
            email = email;
            hourlyPay = hourpay;
            SSN = ssn;
            accountNumber = acc;
            bankName = bankName;
            bankRouting = routing;

        }
        public MainClass(int id, DateTime checkin, DateTime checkout)
        {
            id = id;
            checkin = checkin;
            checkout = checkout;

        }
        public int CompareTo(object o)
        {
            int returnVal;
            MainClass temp = (MainClass)o;
            if (this.id > temp.id)
                returnVal = 1;
            else
               if (this.id < temp.id)
                returnVal = -1;
            else
                returnVal = 0;
            return returnVal;
        }

    }
    
    public class bbbc
    {

        public int x;
    }
}
