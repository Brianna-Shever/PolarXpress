﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MainClassLibrary;

namespace Payroll
{
    public partial class Main : Form
    {
      
        public static List<MainClass> empList = new List<MainClass>();
        public Main()
        {
            InitializeComponent();
        }
        

        private void Main_Load(object sender, EventArgs e)
        {

        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            Login df = new Login();
            df.ShowDialog();
        }

        private void btnEmp_Click(object sender, EventArgs e)
        {
            Form1 df = new Form1();

            df.ShowDialog();
        }

        private void btnPayment_Click(object sender, EventArgs e)
        {
            Paymentcs df = new Paymentcs();
            df.ShowDialog();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
