﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Payroll
{
    public partial class Paymentcs : Form
    {
        public Paymentcs()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(lblAccountN.Text))
            {
                MessageBox.Show(lblAccountN, "Required Employee ID!");
            }
            Int32 x = 0;
            Int32.TryParse(lblAccountN.Text, out x);
            if (x <= 0)
            {
                MessageBox.Show("Employee ID Must be more than Zero");
            }


        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            Int32 x = 0;
            Int32.TryParse(textBoxAccountN.Text, out x);
            if (x <= 0)
            {
                MessageBox.Show("Employee Account Number Must be more than Zero");
            }
        }

        private void Paymentcs_Load(object sender, EventArgs e)
        {

        }
    }
}
