﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Payroll
{
    public partial class Main : Form
    {
      
        //public static List<MainClass> empList = new List<MainClass>();
        public Main()
        {
            InitializeComponent();
        }
        private void btnAddNew_Click(object sender, EventArgs e)
        {
            Form1 df = new Form1();

            df.ShowDialog();
        }



        private void btnChangeE_Click(object sender, EventArgs e)
        {
            Login df = new Login();
            df.ShowDialog();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            Paymentcs df = new Paymentcs();
            df.ShowDialog();
        }

        private void Main_Load(object sender, EventArgs e)
        {

        }
    }
}
