﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Payroll;
using System.Text.RegularExpressions;

namespace Payroll
{
    public partial class Form1 : Form
    {


       
        //public static List<MainClass> empList = new List<MainClass>();
        public Form1()
        {
            InitializeComponent();
        }

        private void txtEmployID_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtEmployID.Text))
            {
                MessageBox.Show(txtEmployID, "Required Employee ID!");
            }
            Int32 x = 0;
            Int32.TryParse(txtEmployID.Text, out x);
            if (x <= 0)
            {
                MessageBox.Show("Employee ID Must be more than Zero");
            }
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            if(hourlypayText.Text == "" )
{
                // display popup box
                MessageBox.Show("Please fill in all fields", "Error");
                hourlypayText.Focus(); // set focus to lastNameTextBox
                return;
            } // end if
        }

        private void emailText_TextChanged(object sender, EventArgs e)
        {
           
            string pattern = "^([0-9a-zA-Z]([-\\.\\w]*[0-9a-zA-Z]*@([0-9a-zA-Z][-\\w]*[0-9a-zA-Z]\\.)+[a-zA-Z]{2,9})$";
            if (emailText.Text == "")
                //if (Regex.IsMatch(emailText.Text, pattern))
            {
                //errorProvider1.SetError(this.emailText, "Please provide valid Mail address");
                // display popup box
                MessageBox.Show("Please fill in all fields", "Error");
                emailText.Focus(); // set focus to lastNameTextBox
                return;
            } // end if
        }

        private void lastNameTextBox_TextChanged(object sender, EventArgs e)
        {
            if (Regex.Match(lastNameTextBox.Text, "^[A-Z][a-zA-Z]*$").Success)
            {
                // last name was incorrect
                MessageBox.Show("Invalid last name");
                lastNameTextBox.Focus();
                return;
            }// end if      
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            // ensures no TextBoxes are empty
            if (lastNameTextBox.Text == "" || firstNameTextBox.Text == "" || addressTextBox.Text == "" || cityTextBox.Text == "" || stateTextBox.Text == "" || zipCodeTextBox.Text == "" ||
phoneTextBox.Text == ""|| HphoneTextBox.Text=="")
            {
                // display popup box
                MessageBox.Show("Please fill in all fields", "Error");
                //firstNameTextBox.Focus(); // set focus to lastNameTextBox
                return;
            } // end if 


        }

        private void firstNameTextBox_TextChanged(object sender, EventArgs e)
        {
            if (Regex.Match(firstNameTextBox.Text, "^[A-Z][a-zA-Z]*$").Success)
            {
                // first name was incorrect
                MessageBox.Show("Invalid first name", "Message");
                firstNameTextBox.Focus();
                return;
            } // end if 
        }

        private void cityTextBox_TextChanged(object sender, EventArgs e)
        {
            string text = "124 street";

            if (!Regex.Match(Text, @"^([a-zA-Z]+|[a-zA-Z]+\s[a-zA-Z]+)$").Success)
            {
                Console.WriteLine("Invalid city");
            }

            //if (Regex.Match(cityTextBox.Text, @"^([a-zA-Z]+|[a-zA-Z]+\s[a-zA-Z]+)$").Success)
            //{
            //    // city was incorrect
            //    MessageBox.Show("Invalid city", "Message");
            //    cityTextBox.Focus();
            //    return;
            //}// end if 

        }

        private void addressTextBox_TextChanged(object sender, EventArgs e)
        {

            if (Regex.Match(addressTextBox.Text, @"^[0-9]+\s+([a-zA-Z]+|[a-zA-Z]+\s[a-zA-Z]+)$").Success)
            {
                // address was incorrect
                MessageBox.Show("Invalid address");
                addressTextBox.Focus();
                return;
            } // end if 

        }

        private void zipCodeTextBox_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {
            if (Regex.Match(zipCodeTextBox.Text, @"^\d{5}$").Success)
            {
                // zip was incorrect
                MessageBox.Show("Invalid zip code");
                zipCodeTextBox.Focus();
                return;
            } // end if
        }

        private void phoneTextBox_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {
            if (Regex.Match(phoneTextBox.Text, @"^[1-9]\d{2}-[1-9]\d{2}-\d{4}$").Success)
            {
                // phone number was incorrect
                MessageBox.Show("Invalid phone number");
                phoneTextBox.Focus();
                return;
            }// end if 
        }

        private void HphoneTextBox_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {
            if (Regex.Match(HphoneTextBox.Text, @"^[1-9]\d{2}-[1-9]\d{2}-\d{4}$").Success)
            {
                // phone number was incorrect
                MessageBox.Show("Invalid phone number");
                HphoneTextBox.Focus();
                return;
            }// end if 
        }

        private void bankroutingText_TextChanged(object sender, EventArgs e)
        {

        }

        private void bankNText_TextChanged(object sender, EventArgs e)
        {
            if (Regex.Match(bankNText.Text, "^[A-Z][a-zA-Z]*$").Success)
            {
                // first name was incorrect
                MessageBox.Show("Invalid Bank name", "Message");
                bankNText.Focus();
                return;
            } // end if 
        }
    }
}
