﻿namespace Payroll
{
    partial class Paymentcs
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblStudentG = new System.Windows.Forms.Label();
            this.lblTotalHours = new System.Windows.Forms.Label();
            this.txtTotalHours = new System.Windows.Forms.TextBox();
            this.lblPymentDate = new System.Windows.Forms.Label();
            this.lblPayment = new System.Windows.Forms.Label();
            this.txtPayment = new System.Windows.Forms.TextBox();
            this.lblAccountN = new System.Windows.Forms.Label();
            this.textBoxAccountN = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txtPymentDate = new System.Windows.Forms.MaskedTextBox();
            this.textBoxTax = new System.Windows.Forms.TextBox();
            this.lblTax = new System.Windows.Forms.Label();
            this.btnReturn = new System.Windows.Forms.Button();
            this.lblHourPay = new System.Windows.Forms.Label();
            this.txtHourPay = new System.Windows.Forms.TextBox();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.txtEmployID = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblStudentG
            // 
            this.lblStudentG.AutoSize = true;
            this.lblStudentG.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStudentG.Location = new System.Drawing.Point(147, 5);
            this.lblStudentG.Name = "lblStudentG";
            this.lblStudentG.Size = new System.Drawing.Size(136, 29);
            this.lblStudentG.TabIndex = 156;
            this.lblStudentG.Text = "Pay Check";
            // 
            // lblTotalHours
            // 
            this.lblTotalHours.AutoSize = true;
            this.lblTotalHours.Location = new System.Drawing.Point(20, 262);
            this.lblTotalHours.Name = "lblTotalHours";
            this.lblTotalHours.Size = new System.Drawing.Size(86, 17);
            this.lblTotalHours.TabIndex = 155;
            this.lblTotalHours.Text = "Total Hours:";
            // 
            // txtTotalHours
            // 
            this.txtTotalHours.Location = new System.Drawing.Point(172, 262);
            this.txtTotalHours.Name = "txtTotalHours";
            this.txtTotalHours.Size = new System.Drawing.Size(100, 22);
            this.txtTotalHours.TabIndex = 154;
            // 
            // lblPymentDate
            // 
            this.lblPymentDate.AutoSize = true;
            this.lblPymentDate.Location = new System.Drawing.Point(20, 198);
            this.lblPymentDate.Name = "lblPymentDate";
            this.lblPymentDate.Size = new System.Drawing.Size(101, 17);
            this.lblPymentDate.TabIndex = 153;
            this.lblPymentDate.Text = "Payment Date:";
            // 
            // lblPayment
            // 
            this.lblPayment.AutoSize = true;
            this.lblPayment.Location = new System.Drawing.Point(20, 165);
            this.lblPayment.Name = "lblPayment";
            this.lblPayment.Size = new System.Drawing.Size(67, 17);
            this.lblPayment.TabIndex = 151;
            this.lblPayment.Text = "Payment:";
            // 
            // txtPayment
            // 
            this.txtPayment.Location = new System.Drawing.Point(172, 165);
            this.txtPayment.Name = "txtPayment";
            this.txtPayment.Size = new System.Drawing.Size(100, 22);
            this.txtPayment.TabIndex = 150;
            // 
            // lblAccountN
            // 
            this.lblAccountN.AutoSize = true;
            this.lblAccountN.Location = new System.Drawing.Point(20, 122);
            this.lblAccountN.Name = "lblAccountN";
            this.lblAccountN.Size = new System.Drawing.Size(117, 17);
            this.lblAccountN.TabIndex = 149;
            this.lblAccountN.Text = "Account Number:";
            this.lblAccountN.Click += new System.EventHandler(this.label1_Click);
            // 
            // textBoxAccountN
            // 
            this.textBoxAccountN.Location = new System.Drawing.Point(172, 122);
            this.textBoxAccountN.Name = "textBoxAccountN";
            this.textBoxAccountN.Size = new System.Drawing.Size(100, 22);
            this.textBoxAccountN.TabIndex = 148;
            this.textBoxAccountN.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(20, 78);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(53, 17);
            this.label15.TabIndex = 147;
            this.label15.Text = "EmpID:";
            // 
            // txtPymentDate
            // 
            this.txtPymentDate.Location = new System.Drawing.Point(172, 198);
            this.txtPymentDate.Mask = "00/00/0000";
            this.txtPymentDate.Name = "txtPymentDate";
            this.txtPymentDate.Size = new System.Drawing.Size(102, 22);
            this.txtPymentDate.TabIndex = 159;
            this.txtPymentDate.ValidatingType = typeof(System.DateTime);
            // 
            // textBoxTax
            // 
            this.textBoxTax.Location = new System.Drawing.Point(172, 294);
            this.textBoxTax.Name = "textBoxTax";
            this.textBoxTax.Size = new System.Drawing.Size(100, 22);
            this.textBoxTax.TabIndex = 160;
            // 
            // lblTax
            // 
            this.lblTax.AutoSize = true;
            this.lblTax.Location = new System.Drawing.Point(20, 294);
            this.lblTax.Name = "lblTax";
            this.lblTax.Size = new System.Drawing.Size(35, 17);
            this.lblTax.TabIndex = 161;
            this.lblTax.Text = "Tax:";
            // 
            // btnReturn
            // 
            this.btnReturn.Location = new System.Drawing.Point(183, 322);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Size = new System.Drawing.Size(153, 46);
            this.btnReturn.TabIndex = 167;
            this.btnReturn.Text = "Return To menu";
            this.btnReturn.UseVisualStyleBackColor = true;
            // 
            // lblHourPay
            // 
            this.lblHourPay.AutoSize = true;
            this.lblHourPay.Location = new System.Drawing.Point(20, 226);
            this.lblHourPay.Name = "lblHourPay";
            this.lblHourPay.Size = new System.Drawing.Size(71, 17);
            this.lblHourPay.TabIndex = 171;
            this.lblHourPay.Text = "Hour Pay:";
            // 
            // txtHourPay
            // 
            this.txtHourPay.Location = new System.Drawing.Point(172, 226);
            this.txtHourPay.Name = "txtHourPay";
            this.txtHourPay.Size = new System.Drawing.Size(100, 22);
            this.txtHourPay.TabIndex = 170;
            // 
            // btnSubmit
            // 
            this.btnSubmit.Location = new System.Drawing.Point(-3, 322);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(164, 46);
            this.btnSubmit.TabIndex = 172;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.UseVisualStyleBackColor = true;
            // 
            // txtEmployID
            // 
            this.txtEmployID.Location = new System.Drawing.Point(172, 78);
            this.txtEmployID.Name = "txtEmployID";
            this.txtEmployID.Size = new System.Drawing.Size(100, 22);
            this.txtEmployID.TabIndex = 146;
            // 
            // Paymentcs
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Payroll.Properties.Resources.polarxpress;
            this.ClientSize = new System.Drawing.Size(441, 374);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.lblHourPay);
            this.Controls.Add(this.txtHourPay);
            this.Controls.Add(this.btnReturn);
            this.Controls.Add(this.lblTax);
            this.Controls.Add(this.textBoxTax);
            this.Controls.Add(this.txtPymentDate);
            this.Controls.Add(this.lblStudentG);
            this.Controls.Add(this.lblTotalHours);
            this.Controls.Add(this.txtTotalHours);
            this.Controls.Add(this.lblPymentDate);
            this.Controls.Add(this.lblPayment);
            this.Controls.Add(this.txtPayment);
            this.Controls.Add(this.lblAccountN);
            this.Controls.Add(this.textBoxAccountN);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.txtEmployID);
            this.Name = "Paymentcs";
            this.Text = "payment";
            this.Load += new System.EventHandler(this.Paymentcs_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblStudentG;
        private System.Windows.Forms.Label lblTotalHours;
        private System.Windows.Forms.TextBox txtTotalHours;
        private System.Windows.Forms.Label lblPymentDate;
        private System.Windows.Forms.Label lblPayment;
        private System.Windows.Forms.TextBox txtPayment;
        private System.Windows.Forms.Label lblAccountN;
        private System.Windows.Forms.TextBox textBoxAccountN;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.MaskedTextBox txtPymentDate;
        private System.Windows.Forms.TextBox textBoxTax;
        private System.Windows.Forms.Label lblTax;
        private System.Windows.Forms.Button btnReturn;
        private System.Windows.Forms.Label lblHourPay;
        private System.Windows.Forms.TextBox txtHourPay;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.TextBox txtEmployID;
    }
}