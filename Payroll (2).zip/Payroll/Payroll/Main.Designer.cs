﻿namespace Payroll
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblMainMenu = new System.Windows.Forms.Label();
            this.btnEmployee = new System.Windows.Forms.Button();
            this.btnLoginAndout = new System.Windows.Forms.Button();
            this.btnPayment = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnReport = new System.Windows.Forms.Button();
            this.btnPrintWForm = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblMainMenu
            // 
            this.lblMainMenu.AutoSize = true;
            this.lblMainMenu.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMainMenu.Location = new System.Drawing.Point(182, 31);
            this.lblMainMenu.Name = "lblMainMenu";
            this.lblMainMenu.Size = new System.Drawing.Size(140, 29);
            this.lblMainMenu.TabIndex = 107;
            this.lblMainMenu.Text = "Main Menu";
            // 
            // btnEmployee
            // 
            this.btnEmployee.Location = new System.Drawing.Point(275, 145);
            this.btnEmployee.Name = "btnEmployee";
            this.btnEmployee.Size = new System.Drawing.Size(219, 46);
            this.btnEmployee.TabIndex = 143;
            this.btnEmployee.Text = "Employee";
            this.btnEmployee.UseVisualStyleBackColor = true;
            // 
            // btnLoginAndout
            // 
            this.btnLoginAndout.Location = new System.Drawing.Point(50, 145);
            this.btnLoginAndout.Name = "btnLoginAndout";
            this.btnLoginAndout.Size = new System.Drawing.Size(219, 46);
            this.btnLoginAndout.TabIndex = 144;
            this.btnLoginAndout.Text = "Login and out";
            this.btnLoginAndout.UseVisualStyleBackColor = true;
            // 
            // btnPayment
            // 
            this.btnPayment.Location = new System.Drawing.Point(50, 196);
            this.btnPayment.Name = "btnPayment";
            this.btnPayment.Size = new System.Drawing.Size(219, 46);
            this.btnPayment.TabIndex = 145;
            this.btnPayment.Text = "Payment";
            this.btnPayment.UseVisualStyleBackColor = true;
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(50, 312);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(444, 46);
            this.btnExit.TabIndex = 147;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            // 
            // btnReport
            // 
            this.btnReport.Location = new System.Drawing.Point(275, 197);
            this.btnReport.Name = "btnReport";
            this.btnReport.Size = new System.Drawing.Size(219, 46);
            this.btnReport.TabIndex = 149;
            this.btnReport.Text = "Report";
            this.btnReport.UseVisualStyleBackColor = true;
            // 
            // btnPrintWForm
            // 
            this.btnPrintWForm.Location = new System.Drawing.Point(50, 248);
            this.btnPrintWForm.Name = "btnPrintWForm";
            this.btnPrintWForm.Size = new System.Drawing.Size(444, 46);
            this.btnPrintWForm.TabIndex = 150;
            this.btnPrintWForm.Text = "Print  W-2 Form";
            this.btnPrintWForm.UseVisualStyleBackColor = true;
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Payroll.Properties.Resources.polarxpress;
            this.ClientSize = new System.Drawing.Size(555, 409);
            this.Controls.Add(this.btnPrintWForm);
            this.Controls.Add(this.btnReport);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnPayment);
            this.Controls.Add(this.btnLoginAndout);
            this.Controls.Add(this.btnEmployee);
            this.Controls.Add(this.lblMainMenu);
            this.Name = "Main";
            this.Text = "Main";
            this.Load += new System.EventHandler(this.Main_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblMainMenu;
        private System.Windows.Forms.Button btnEmployee;
        private System.Windows.Forms.Button btnLoginAndout;
        private System.Windows.Forms.Button btnPayment;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnReport;
        private System.Windows.Forms.Button btnPrintWForm;
    }
}