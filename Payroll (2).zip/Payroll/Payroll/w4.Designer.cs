﻿namespace Payroll
{
    partial class w4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblStudentG = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblFNMinitial = new System.Windows.Forms.Label();
            this.txtFNMinitial = new System.Windows.Forms.TextBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.lblName = new System.Windows.Forms.Label();
            this.lblSSC = new System.Windows.Forms.Label();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.lblAddress = new System.Windows.Forms.Label();
            this.lblCityZipcode = new System.Windows.Forms.Label();
            this.checkBoxSingle = new System.Windows.Forms.CheckBox();
            this.checkBoxMarried = new System.Windows.Forms.CheckBox();
            this.checkBoxMWHSrate = new System.Windows.Forms.CheckBox();
            this.checkBoxLastDiffer = new System.Windows.Forms.CheckBox();
            this.lblLastDiffer = new System.Windows.Forms.Label();
            this.textBoxTNAforeach = new System.Windows.Forms.TextBox();
            this.lblTNAforeach = new System.Windows.Forms.Label();
            this.lblAWpaycheck = new System.Windows.Forms.Label();
            this.lblClaim = new System.Windows.Forms.Label();
            this.textBoxEmplSign = new System.Windows.Forms.TextBox();
            this.lblEmplSign = new System.Windows.Forms.Label();
            this.lblDate = new System.Windows.Forms.Label();
            this.textBoxEmployAddress = new System.Windows.Forms.TextBox();
            this.lblEmplAddress = new System.Windows.Forms.Label();
            this.txtOfficeCode = new System.Windows.Forms.TextBox();
            this.lblOfficeCode = new System.Windows.Forms.Label();
            this.txtEmployeeIDN = new System.Windows.Forms.TextBox();
            this.lblEmployeeIDN = new System.Windows.Forms.Label();
            this.txtSSC = new System.Windows.Forms.MaskedTextBox();
            this.txtDate = new System.Windows.Forms.MaskedTextBox();
            this.txtCityZipcode = new System.Windows.Forms.MaskedTextBox();
            this.checkBoxAWpaycheck = new System.Windows.Forms.CheckBox();
            this.checkBoxClaim = new System.Windows.Forms.CheckBox();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.btnReturn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblStudentG
            // 
            this.lblStudentG.AutoSize = true;
            this.lblStudentG.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStudentG.Location = new System.Drawing.Point(1, 9);
            this.lblStudentG.Name = "lblStudentG";
            this.lblStudentG.Size = new System.Drawing.Size(127, 29);
            this.lblStudentG.TabIndex = 108;
            this.lblStudentG.Text = "Form W-4";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(176, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(537, 29);
            this.label1.TabIndex = 109;
            this.label1.Text = "Employee\'s Withholding allowance Certifcate";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(931, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 29);
            this.label2.TabIndex = 110;
            this.label2.Text = "2018";
            // 
            // lblFNMinitial
            // 
            this.lblFNMinitial.AutoSize = true;
            this.lblFNMinitial.Location = new System.Drawing.Point(12, 86);
            this.lblFNMinitial.Name = "lblFNMinitial";
            this.lblFNMinitial.Size = new System.Drawing.Size(225, 17);
            this.lblFNMinitial.TabIndex = 114;
            this.lblFNMinitial.Text = "Your First name and middle initial::";
            // 
            // txtFNMinitial
            // 
            this.txtFNMinitial.Location = new System.Drawing.Point(234, 83);
            this.txtFNMinitial.Name = "txtFNMinitial";
            this.txtFNMinitial.Size = new System.Drawing.Size(143, 22);
            this.txtFNMinitial.TabIndex = 115;
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(476, 83);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(154, 22);
            this.txtName.TabIndex = 117;
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(391, 83);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(80, 17);
            this.lblName.TabIndex = 116;
            this.lblName.Text = "Last Name:";
            // 
            // lblSSC
            // 
            this.lblSSC.AutoSize = true;
            this.lblSSC.Location = new System.Drawing.Point(634, 81);
            this.lblSSC.Name = "lblSSC";
            this.lblSSC.Size = new System.Drawing.Size(193, 17);
            this.lblSSC.TabIndex = 118;
            this.lblSSC.Text = "Your Social Security Number:";
            // 
            // txtAddress
            // 
            this.txtAddress.Location = new System.Drawing.Point(121, 127);
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(336, 22);
            this.txtAddress.TabIndex = 121;
            // 
            // lblAddress
            // 
            this.lblAddress.AutoSize = true;
            this.lblAddress.Location = new System.Drawing.Point(12, 127);
            this.lblAddress.Name = "lblAddress";
            this.lblAddress.Size = new System.Drawing.Size(105, 17);
            this.lblAddress.TabIndex = 120;
            this.lblAddress.Text = "Home Address:";
            // 
            // lblCityZipcode
            // 
            this.lblCityZipcode.AutoSize = true;
            this.lblCityZipcode.Location = new System.Drawing.Point(12, 172);
            this.lblCityZipcode.Name = "lblCityZipcode";
            this.lblCityZipcode.Size = new System.Drawing.Size(101, 17);
            this.lblCityZipcode.TabIndex = 122;
            this.lblCityZipcode.Text = "City ,ZIP Code:";
            // 
            // checkBoxSingle
            // 
            this.checkBoxSingle.AutoSize = true;
            this.checkBoxSingle.Checked = true;
            this.checkBoxSingle.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxSingle.Location = new System.Drawing.Point(500, 127);
            this.checkBoxSingle.Name = "checkBoxSingle";
            this.checkBoxSingle.Size = new System.Drawing.Size(69, 21);
            this.checkBoxSingle.TabIndex = 124;
            this.checkBoxSingle.Text = "Single";
            this.checkBoxSingle.UseVisualStyleBackColor = true;
            // 
            // checkBoxMarried
            // 
            this.checkBoxMarried.AutoSize = true;
            this.checkBoxMarried.Location = new System.Drawing.Point(587, 129);
            this.checkBoxMarried.Name = "checkBoxMarried";
            this.checkBoxMarried.Size = new System.Drawing.Size(78, 21);
            this.checkBoxMarried.TabIndex = 125;
            this.checkBoxMarried.Text = "Married";
            this.checkBoxMarried.UseVisualStyleBackColor = true;
            // 
            // checkBoxMWHSrate
            // 
            this.checkBoxMWHSrate.AutoSize = true;
            this.checkBoxMWHSrate.Location = new System.Drawing.Point(687, 126);
            this.checkBoxMWHSrate.Name = "checkBoxMWHSrate";
            this.checkBoxMWHSrate.Size = new System.Drawing.Size(291, 21);
            this.checkBoxMWHSrate.TabIndex = 126;
            this.checkBoxMWHSrate.Text = "Married, but withhold at higher single rate";
            this.checkBoxMWHSrate.UseVisualStyleBackColor = true;
            // 
            // checkBoxLastDiffer
            // 
            this.checkBoxLastDiffer.AutoSize = true;
            this.checkBoxLastDiffer.Location = new System.Drawing.Point(982, 172);
            this.checkBoxLastDiffer.Name = "checkBoxLastDiffer";
            this.checkBoxLastDiffer.Size = new System.Drawing.Size(18, 17);
            this.checkBoxLastDiffer.TabIndex = 127;
            this.checkBoxLastDiffer.UseVisualStyleBackColor = true;
            // 
            // lblLastDiffer
            // 
            this.lblLastDiffer.AutoSize = true;
            this.lblLastDiffer.Location = new System.Drawing.Point(497, 175);
            this.lblLastDiffer.Name = "lblLastDiffer";
            this.lblLastDiffer.Size = new System.Drawing.Size(454, 17);
            this.lblLastDiffer.TabIndex = 128;
            this.lblLastDiffer.Text = "If  your last name differ\'s from that shown on your social secuity card, .:";
            // 
            // textBoxTNAforeach
            // 
            this.textBoxTNAforeach.Location = new System.Drawing.Point(286, 217);
            this.textBoxTNAforeach.Name = "textBoxTNAforeach";
            this.textBoxTNAforeach.Size = new System.Drawing.Size(154, 22);
            this.textBoxTNAforeach.TabIndex = 130;
            // 
            // lblTNAforeach
            // 
            this.lblTNAforeach.AutoSize = true;
            this.lblTNAforeach.Location = new System.Drawing.Point(12, 217);
            this.lblTNAforeach.Name = "lblTNAforeach";
            this.lblTNAforeach.Size = new System.Drawing.Size(259, 17);
            this.lblTNAforeach.TabIndex = 129;
            this.lblTNAforeach.Text = "Total number of allownces you claiming:";
            // 
            // lblAWpaycheck
            // 
            this.lblAWpaycheck.AutoSize = true;
            this.lblAWpaycheck.Location = new System.Drawing.Point(12, 263);
            this.lblAWpaycheck.Name = "lblAWpaycheck";
            this.lblAWpaycheck.Size = new System.Drawing.Size(417, 17);
            this.lblAWpaycheck.TabIndex = 131;
            this.lblAWpaycheck.Text = "Additional amount ,if any , you want withheld from each paycheck";
            // 
            // lblClaim
            // 
            this.lblClaim.AutoSize = true;
            this.lblClaim.Location = new System.Drawing.Point(12, 311);
            this.lblClaim.Name = "lblClaim";
            this.lblClaim.Size = new System.Drawing.Size(399, 17);
            this.lblClaim.TabIndex = 133;
            this.lblClaim.Text = "I claim  exemption from withholding for 2018 , and I certify that:";
            // 
            // textBoxEmplSign
            // 
            this.textBoxEmplSign.Location = new System.Drawing.Point(187, 368);
            this.textBoxEmplSign.Name = "textBoxEmplSign";
            this.textBoxEmplSign.Size = new System.Drawing.Size(478, 22);
            this.textBoxEmplSign.TabIndex = 136;
            // 
            // lblEmplSign
            // 
            this.lblEmplSign.AutoSize = true;
            this.lblEmplSign.Location = new System.Drawing.Point(12, 368);
            this.lblEmplSign.Name = "lblEmplSign";
            this.lblEmplSign.Size = new System.Drawing.Size(149, 17);
            this.lblEmplSign.TabIndex = 135;
            this.lblEmplSign.Text = "Employee\'s Signature:";
            // 
            // lblDate
            // 
            this.lblDate.AutoSize = true;
            this.lblDate.Location = new System.Drawing.Point(738, 368);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(38, 17);
            this.lblDate.TabIndex = 137;
            this.lblDate.Text = "Date";
            // 
            // textBoxEmployAddress
            // 
            this.textBoxEmployAddress.Location = new System.Drawing.Point(221, 412);
            this.textBoxEmployAddress.Name = "textBoxEmployAddress";
            this.textBoxEmployAddress.Size = new System.Drawing.Size(247, 22);
            this.textBoxEmployAddress.TabIndex = 140;
            // 
            // lblEmplAddress
            // 
            this.lblEmplAddress.AutoSize = true;
            this.lblEmplAddress.Location = new System.Drawing.Point(12, 415);
            this.lblEmplAddress.Name = "lblEmplAddress";
            this.lblEmplAddress.Size = new System.Drawing.Size(206, 17);
            this.lblEmplAddress.TabIndex = 139;
            this.lblEmplAddress.Text = "Employer\'s Name and Address:";
            // 
            // txtOfficeCode
            // 
            this.txtOfficeCode.Location = new System.Drawing.Point(571, 412);
            this.txtOfficeCode.Name = "txtOfficeCode";
            this.txtOfficeCode.Size = new System.Drawing.Size(115, 22);
            this.txtOfficeCode.TabIndex = 142;
            // 
            // lblOfficeCode
            // 
            this.lblOfficeCode.AutoSize = true;
            this.lblOfficeCode.Location = new System.Drawing.Point(486, 412);
            this.lblOfficeCode.Name = "lblOfficeCode";
            this.lblOfficeCode.Size = new System.Drawing.Size(84, 17);
            this.lblOfficeCode.TabIndex = 141;
            this.lblOfficeCode.Text = "Office code:";
            // 
            // txtEmployeeIDN
            // 
            this.txtEmployeeIDN.Location = new System.Drawing.Point(905, 415);
            this.txtEmployeeIDN.Name = "txtEmployeeIDN";
            this.txtEmployeeIDN.Size = new System.Drawing.Size(95, 22);
            this.txtEmployeeIDN.TabIndex = 144;
            // 
            // lblEmployeeIDN
            // 
            this.lblEmployeeIDN.AutoSize = true;
            this.lblEmployeeIDN.Location = new System.Drawing.Point(694, 415);
            this.lblEmployeeIDN.Name = "lblEmployeeIDN";
            this.lblEmployeeIDN.Size = new System.Drawing.Size(206, 17);
            this.lblEmployeeIDN.TabIndex = 143;
            this.lblEmployeeIDN.Text = "Employer identification number:";
            // 
            // txtSSC
            // 
            this.txtSSC.Location = new System.Drawing.Point(851, 83);
            this.txtSSC.Mask = "000-00-0000";
            this.txtSSC.Name = "txtSSC";
            this.txtSSC.Size = new System.Drawing.Size(149, 22);
            this.txtSSC.TabIndex = 161;
            // 
            // txtDate
            // 
            this.txtDate.Location = new System.Drawing.Point(782, 368);
            this.txtDate.Mask = "00/00/0000";
            this.txtDate.Name = "txtDate";
            this.txtDate.Size = new System.Drawing.Size(218, 22);
            this.txtDate.TabIndex = 162;
            this.txtDate.ValidatingType = typeof(System.DateTime);
            // 
            // txtCityZipcode
            // 
            this.txtCityZipcode.Location = new System.Drawing.Point(119, 170);
            this.txtCityZipcode.Mask = "00000-9999";
            this.txtCityZipcode.Name = "txtCityZipcode";
            this.txtCityZipcode.Size = new System.Drawing.Size(338, 22);
            this.txtCityZipcode.TabIndex = 163;
            // 
            // checkBoxAWpaycheck
            // 
            this.checkBoxAWpaycheck.AutoSize = true;
            this.checkBoxAWpaycheck.Checked = true;
            this.checkBoxAWpaycheck.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxAWpaycheck.Location = new System.Drawing.Point(462, 264);
            this.checkBoxAWpaycheck.Name = "checkBoxAWpaycheck";
            this.checkBoxAWpaycheck.Size = new System.Drawing.Size(18, 17);
            this.checkBoxAWpaycheck.TabIndex = 166;
            this.checkBoxAWpaycheck.UseVisualStyleBackColor = true;
            // 
            // checkBoxClaim
            // 
            this.checkBoxClaim.AutoSize = true;
            this.checkBoxClaim.Location = new System.Drawing.Point(429, 311);
            this.checkBoxClaim.Name = "checkBoxClaim";
            this.checkBoxClaim.Size = new System.Drawing.Size(18, 17);
            this.checkBoxClaim.TabIndex = 167;
            this.checkBoxClaim.UseVisualStyleBackColor = true;
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(192, 469);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(90, 46);
            this.btnDelete.TabIndex = 178;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(109, 469);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(90, 46);
            this.btnUpdate.TabIndex = 177;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            // 
            // btnSubmit
            // 
            this.btnSubmit.Location = new System.Drawing.Point(13, 469);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(90, 46);
            this.btnSubmit.TabIndex = 176;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.UseVisualStyleBackColor = true;
            // 
            // btnReturn
            // 
            this.btnReturn.Location = new System.Drawing.Point(286, 469);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Size = new System.Drawing.Size(112, 46);
            this.btnReturn.TabIndex = 175;
            this.btnReturn.Text = "Return To menu";
            this.btnReturn.UseVisualStyleBackColor = true;
            // 
            // w4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Payroll.Properties.Resources.polarxpress;
            this.ClientSize = new System.Drawing.Size(1006, 518);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.btnReturn);
            this.Controls.Add(this.checkBoxClaim);
            this.Controls.Add(this.checkBoxAWpaycheck);
            this.Controls.Add(this.txtCityZipcode);
            this.Controls.Add(this.txtDate);
            this.Controls.Add(this.txtSSC);
            this.Controls.Add(this.txtEmployeeIDN);
            this.Controls.Add(this.lblEmployeeIDN);
            this.Controls.Add(this.txtOfficeCode);
            this.Controls.Add(this.lblOfficeCode);
            this.Controls.Add(this.textBoxEmployAddress);
            this.Controls.Add(this.lblEmplAddress);
            this.Controls.Add(this.lblDate);
            this.Controls.Add(this.textBoxEmplSign);
            this.Controls.Add(this.lblEmplSign);
            this.Controls.Add(this.lblClaim);
            this.Controls.Add(this.lblAWpaycheck);
            this.Controls.Add(this.textBoxTNAforeach);
            this.Controls.Add(this.lblTNAforeach);
            this.Controls.Add(this.lblLastDiffer);
            this.Controls.Add(this.checkBoxLastDiffer);
            this.Controls.Add(this.checkBoxMWHSrate);
            this.Controls.Add(this.checkBoxMarried);
            this.Controls.Add(this.checkBoxSingle);
            this.Controls.Add(this.lblCityZipcode);
            this.Controls.Add(this.txtAddress);
            this.Controls.Add(this.lblAddress);
            this.Controls.Add(this.lblSSC);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.txtFNMinitial);
            this.Controls.Add(this.lblFNMinitial);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblStudentG);
            this.Name = "w4";
            this.Text = "w4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblStudentG;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblFNMinitial;
        private System.Windows.Forms.TextBox txtFNMinitial;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblSSC;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.Label lblAddress;
        private System.Windows.Forms.Label lblCityZipcode;
        private System.Windows.Forms.CheckBox checkBoxSingle;
        private System.Windows.Forms.CheckBox checkBoxMarried;
        private System.Windows.Forms.CheckBox checkBoxMWHSrate;
        private System.Windows.Forms.CheckBox checkBoxLastDiffer;
        private System.Windows.Forms.Label lblLastDiffer;
        private System.Windows.Forms.TextBox textBoxTNAforeach;
        private System.Windows.Forms.Label lblTNAforeach;
        private System.Windows.Forms.Label lblAWpaycheck;
        private System.Windows.Forms.Label lblClaim;
        private System.Windows.Forms.TextBox textBoxEmplSign;
        private System.Windows.Forms.Label lblEmplSign;
        private System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.TextBox textBoxEmployAddress;
        private System.Windows.Forms.Label lblEmplAddress;
        private System.Windows.Forms.TextBox txtOfficeCode;
        private System.Windows.Forms.Label lblOfficeCode;
        private System.Windows.Forms.TextBox txtEmployeeIDN;
        private System.Windows.Forms.Label lblEmployeeIDN;
        private System.Windows.Forms.MaskedTextBox txtSSC;
        private System.Windows.Forms.MaskedTextBox txtDate;
        private System.Windows.Forms.MaskedTextBox txtCityZipcode;
        private System.Windows.Forms.CheckBox checkBoxAWpaycheck;
        private System.Windows.Forms.CheckBox checkBoxClaim;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.Button btnReturn;
    }
}