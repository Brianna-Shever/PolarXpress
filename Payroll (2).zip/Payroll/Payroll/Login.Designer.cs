﻿namespace Payroll
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblEmpID = new System.Windows.Forms.Label();
            this.txtEmployID = new System.Windows.Forms.TextBox();
            this.lblStudentG = new System.Windows.Forms.Label();
            this.btnReturn = new System.Windows.Forms.Button();
            this.btnCheckout = new System.Windows.Forms.Button();
            this.btnCheckin = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblEmpID
            // 
            this.lblEmpID.AutoSize = true;
            this.lblEmpID.Location = new System.Drawing.Point(12, 82);
            this.lblEmpID.Name = "lblEmpID";
            this.lblEmpID.Size = new System.Drawing.Size(53, 17);
            this.lblEmpID.TabIndex = 125;
            this.lblEmpID.Text = "EmpID:";
            // 
            // txtEmployID
            // 
            this.txtEmployID.Location = new System.Drawing.Point(172, 82);
            this.txtEmployID.Name = "txtEmployID";
            this.txtEmployID.Size = new System.Drawing.Size(100, 22);
            this.txtEmployID.TabIndex = 124;
            // 
            // lblStudentG
            // 
            this.lblStudentG.AutoSize = true;
            this.lblStudentG.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStudentG.Location = new System.Drawing.Point(121, 9);
            this.lblStudentG.Name = "lblStudentG";
            this.lblStudentG.Size = new System.Drawing.Size(178, 29);
            this.lblStudentG.TabIndex = 134;
            this.lblStudentG.Text = "Login And Out";
            // 
            // btnReturn
            // 
            this.btnReturn.Location = new System.Drawing.Point(110, 296);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Size = new System.Drawing.Size(206, 46);
            this.btnReturn.TabIndex = 145;
            this.btnReturn.Text = "Return To menu";
            this.btnReturn.UseVisualStyleBackColor = true;
            // 
            // btnCheckout
            // 
            this.btnCheckout.Location = new System.Drawing.Point(15, 185);
            this.btnCheckout.Name = "btnCheckout";
            this.btnCheckout.Size = new System.Drawing.Size(367, 46);
            this.btnCheckout.TabIndex = 147;
            this.btnCheckout.Text = "check Out";
            this.btnCheckout.UseVisualStyleBackColor = true;
            // 
            // btnCheckin
            // 
            this.btnCheckin.Location = new System.Drawing.Point(15, 122);
            this.btnCheckin.Name = "btnCheckin";
            this.btnCheckin.Size = new System.Drawing.Size(367, 46);
            this.btnCheckin.TabIndex = 146;
            this.btnCheckin.Text = "check in ";
            this.btnCheckin.UseVisualStyleBackColor = true;
            // 
            // Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Payroll.Properties.Resources.polarxpress;
            this.ClientSize = new System.Drawing.Size(464, 369);
            this.Controls.Add(this.btnCheckout);
            this.Controls.Add(this.btnCheckin);
            this.Controls.Add(this.btnReturn);
            this.Controls.Add(this.lblStudentG);
            this.Controls.Add(this.lblEmpID);
            this.Controls.Add(this.txtEmployID);
            this.Name = "Login";
            this.Text = "Login";
            this.Load += new System.EventHandler(this.Login_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblEmpID;
        private System.Windows.Forms.TextBox txtEmployID;
        private System.Windows.Forms.Label lblStudentG;
        private System.Windows.Forms.Button btnReturn;
        private System.Windows.Forms.Button btnCheckout;
        private System.Windows.Forms.Button btnCheckin;
    }
}