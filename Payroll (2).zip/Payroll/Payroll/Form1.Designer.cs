﻿namespace Payroll
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.stateTextBox = new System.Windows.Forms.ComboBox();
            this.HphoneTextBox = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBox3 = new System.Windows.Forms.MaskedTextBox();
            this.zipCodeTextBox = new System.Windows.Forms.MaskedTextBox();
            this.phoneTextBox = new System.Windows.Forms.MaskedTextBox();
            this.lblState = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.lblBAN = new System.Windows.Forms.Label();
            this.bankaccnText = new System.Windows.Forms.TextBox();
            this.lblCellP = new System.Windows.Forms.Label();
            this.lblEmail = new System.Windows.Forms.Label();
            this.lblHomeP = new System.Windows.Forms.Label();
            this.emailText = new System.Windows.Forms.TextBox();
            this.lblZip = new System.Windows.Forms.Label();
            this.lblCity = new System.Windows.Forms.Label();
            this.cityTextBox = new System.Windows.Forms.TextBox();
            this.lblAddress = new System.Windows.Forms.Label();
            this.addressTextBox = new System.Windows.Forms.TextBox();
            this.labelLastName = new System.Windows.Forms.Label();
            this.lastNameTextBox = new System.Windows.Forms.TextBox();
            this.lblBirthD = new System.Windows.Forms.Label();
            this.lblFirstName = new System.Windows.Forms.Label();
            this.firstNameTextBox = new System.Windows.Forms.TextBox();
            this.lblStudentG = new System.Windows.Forms.Label();
            this.lblHourlyP = new System.Windows.Forms.Label();
            this.hourlypayText = new System.Windows.Forms.TextBox();
            this.lblSSN = new System.Windows.Forms.Label();
            this.lblEmployID = new System.Windows.Forms.Label();
            this.txtEmployID = new System.Windows.Forms.TextBox();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnUpDate = new System.Windows.Forms.Button();
            this.btnReturn = new System.Windows.Forms.Button();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.btnWform = new System.Windows.Forms.Button();
            this.ssnTextbox = new System.Windows.Forms.MaskedTextBox();
            this.lblBankN = new System.Windows.Forms.Label();
            this.bankNText = new System.Windows.Forms.TextBox();
            this.lblBankName = new System.Windows.Forms.Label();
            this.bankroutingText = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // stateTextBox
            // 
            this.stateTextBox.FormattingEnabled = true;
            this.stateTextBox.Location = new System.Drawing.Point(428, 131);
            this.stateTextBox.Name = "stateTextBox";
            this.stateTextBox.Size = new System.Drawing.Size(100, 24);
            this.stateTextBox.TabIndex = 141;
            this.stateTextBox.Text = "IA";
            // 
            // HphoneTextBox
            // 
            this.HphoneTextBox.Location = new System.Drawing.Point(140, 209);
            this.HphoneTextBox.Mask = "(999) 000-0000";
            this.HphoneTextBox.Name = "HphoneTextBox";
            this.HphoneTextBox.Size = new System.Drawing.Size(102, 22);
            this.HphoneTextBox.TabIndex = 140;
            this.HphoneTextBox.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.HphoneTextBox_MaskInputRejected);
            // 
            // maskedTextBox3
            // 
            this.maskedTextBox3.Location = new System.Drawing.Point(430, 167);
            this.maskedTextBox3.Name = "maskedTextBox3";
            this.maskedTextBox3.Size = new System.Drawing.Size(100, 22);
            this.maskedTextBox3.TabIndex = 182;
            // 
            // zipCodeTextBox
            // 
            this.zipCodeTextBox.Location = new System.Drawing.Point(140, 170);
            this.zipCodeTextBox.Mask = "00000-9999";
            this.zipCodeTextBox.Name = "zipCodeTextBox";
            this.zipCodeTextBox.Size = new System.Drawing.Size(102, 22);
            this.zipCodeTextBox.TabIndex = 138;
            this.zipCodeTextBox.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.zipCodeTextBox_MaskInputRejected);
            // 
            // phoneTextBox
            // 
            this.phoneTextBox.Location = new System.Drawing.Point(428, 209);
            this.phoneTextBox.Mask = "(999) 000-0000";
            this.phoneTextBox.Name = "phoneTextBox";
            this.phoneTextBox.Size = new System.Drawing.Size(102, 22);
            this.phoneTextBox.TabIndex = 137;
            this.phoneTextBox.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.phoneTextBox_MaskInputRejected);
            // 
            // lblState
            // 
            this.lblState.AutoSize = true;
            this.lblState.Location = new System.Drawing.Point(300, 131);
            this.lblState.Name = "lblState";
            this.lblState.Size = new System.Drawing.Size(45, 17);
            this.lblState.TabIndex = 135;
            this.lblState.Text = "State:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(-562, 450);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(45, 17);
            this.label13.TabIndex = 134;
            this.label13.Text = "State:";
            // 
            // lblBAN
            // 
            this.lblBAN.AutoSize = true;
            this.lblBAN.Location = new System.Drawing.Point(300, 295);
            this.lblBAN.Name = "lblBAN";
            this.lblBAN.Size = new System.Drawing.Size(153, 17);
            this.lblBAN.TabIndex = 133;
            this.lblBAN.Text = "Bank Account Number:";
            // 
            // bankaccnText
            // 
            this.bankaccnText.Location = new System.Drawing.Point(461, 295);
            this.bankaccnText.Name = "bankaccnText";
            this.bankaccnText.Size = new System.Drawing.Size(100, 22);
            this.bankaccnText.TabIndex = 132;
            // 
            // lblCellP
            // 
            this.lblCellP.AutoSize = true;
            this.lblCellP.Location = new System.Drawing.Point(300, 209);
            this.lblCellP.Name = "lblCellP";
            this.lblCellP.Size = new System.Drawing.Size(80, 17);
            this.lblCellP.TabIndex = 126;
            this.lblCellP.Text = "Cell Phone:";
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Location = new System.Drawing.Point(12, 253);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(46, 17);
            this.lblEmail.TabIndex = 123;
            this.lblEmail.Text = "Email:";
            // 
            // lblHomeP
            // 
            this.lblHomeP.AutoSize = true;
            this.lblHomeP.Location = new System.Drawing.Point(12, 209);
            this.lblHomeP.Name = "lblHomeP";
            this.lblHomeP.Size = new System.Drawing.Size(94, 17);
            this.lblHomeP.TabIndex = 122;
            this.lblHomeP.Text = "Home Phone:";
            // 
            // emailText
            // 
            this.emailText.Location = new System.Drawing.Point(140, 253);
            this.emailText.Name = "emailText";
            this.emailText.Size = new System.Drawing.Size(152, 22);
            this.emailText.TabIndex = 120;
            this.emailText.TextChanged += new System.EventHandler(this.emailText_TextChanged);
            // 
            // lblZip
            // 
            this.lblZip.AutoSize = true;
            this.lblZip.Location = new System.Drawing.Point(12, 170);
            this.lblZip.Name = "lblZip";
            this.lblZip.Size = new System.Drawing.Size(32, 17);
            this.lblZip.TabIndex = 118;
            this.lblZip.Text = "Zip:";
            // 
            // lblCity
            // 
            this.lblCity.AutoSize = true;
            this.lblCity.Location = new System.Drawing.Point(12, 131);
            this.lblCity.Name = "lblCity";
            this.lblCity.Size = new System.Drawing.Size(35, 17);
            this.lblCity.TabIndex = 117;
            this.lblCity.Text = "City:";
            // 
            // cityTextBox
            // 
            this.cityTextBox.Location = new System.Drawing.Point(142, 128);
            this.cityTextBox.Name = "cityTextBox";
            this.cityTextBox.Size = new System.Drawing.Size(100, 22);
            this.cityTextBox.TabIndex = 116;
            this.cityTextBox.TextChanged += new System.EventHandler(this.cityTextBox_TextChanged);
            // 
            // lblAddress
            // 
            this.lblAddress.AutoSize = true;
            this.lblAddress.Location = new System.Drawing.Point(300, 91);
            this.lblAddress.Name = "lblAddress";
            this.lblAddress.Size = new System.Drawing.Size(64, 17);
            this.lblAddress.TabIndex = 115;
            this.lblAddress.Text = "Address:";
            // 
            // addressTextBox
            // 
            this.addressTextBox.Location = new System.Drawing.Point(428, 91);
            this.addressTextBox.Name = "addressTextBox";
            this.addressTextBox.Size = new System.Drawing.Size(100, 22);
            this.addressTextBox.TabIndex = 114;
            this.addressTextBox.TextChanged += new System.EventHandler(this.addressTextBox_TextChanged);
            // 
            // labelLastName
            // 
            this.labelLastName.AutoSize = true;
            this.labelLastName.Location = new System.Drawing.Point(12, 91);
            this.labelLastName.Name = "labelLastName";
            this.labelLastName.Size = new System.Drawing.Size(80, 17);
            this.labelLastName.TabIndex = 113;
            this.labelLastName.Text = "Last Name:";
            // 
            // lastNameTextBox
            // 
            this.lastNameTextBox.Location = new System.Drawing.Point(140, 91);
            this.lastNameTextBox.Name = "lastNameTextBox";
            this.lastNameTextBox.Size = new System.Drawing.Size(100, 22);
            this.lastNameTextBox.TabIndex = 112;
            this.lastNameTextBox.TextChanged += new System.EventHandler(this.lastNameTextBox_TextChanged);
            // 
            // lblBirthD
            // 
            this.lblBirthD.AutoSize = true;
            this.lblBirthD.Location = new System.Drawing.Point(300, 170);
            this.lblBirthD.Name = "lblBirthD";
            this.lblBirthD.Size = new System.Drawing.Size(75, 17);
            this.lblBirthD.TabIndex = 111;
            this.lblBirthD.Text = "Birth Date:";
            // 
            // lblFirstName
            // 
            this.lblFirstName.AutoSize = true;
            this.lblFirstName.Location = new System.Drawing.Point(300, 54);
            this.lblFirstName.Name = "lblFirstName";
            this.lblFirstName.Size = new System.Drawing.Size(80, 17);
            this.lblFirstName.TabIndex = 110;
            this.lblFirstName.Text = "First Name:";
            // 
            // firstNameTextBox
            // 
            this.firstNameTextBox.Location = new System.Drawing.Point(428, 54);
            this.firstNameTextBox.Name = "firstNameTextBox";
            this.firstNameTextBox.Size = new System.Drawing.Size(100, 22);
            this.firstNameTextBox.TabIndex = 109;
            this.firstNameTextBox.TextChanged += new System.EventHandler(this.firstNameTextBox_TextChanged);
            // 
            // lblStudentG
            // 
            this.lblStudentG.AutoSize = true;
            this.lblStudentG.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStudentG.Location = new System.Drawing.Point(205, -2);
            this.lblStudentG.Name = "lblStudentG";
            this.lblStudentG.Size = new System.Drawing.Size(130, 29);
            this.lblStudentG.TabIndex = 106;
            this.lblStudentG.Text = "Employee";
            // 
            // lblHourlyP
            // 
            this.lblHourlyP.AutoSize = true;
            this.lblHourlyP.Location = new System.Drawing.Point(300, 253);
            this.lblHourlyP.Name = "lblHourlyP";
            this.lblHourlyP.Size = new System.Drawing.Size(81, 17);
            this.lblHourlyP.TabIndex = 145;
            this.lblHourlyP.Text = "Hourly Pay:";
            // 
            // hourlypayText
            // 
            this.hourlypayText.Location = new System.Drawing.Point(428, 253);
            this.hourlypayText.Name = "hourlypayText";
            this.hourlypayText.Size = new System.Drawing.Size(100, 22);
            this.hourlypayText.TabIndex = 144;
            this.hourlypayText.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // lblSSN
            // 
            this.lblSSN.AutoSize = true;
            this.lblSSN.Location = new System.Drawing.Point(12, 294);
            this.lblSSN.Name = "lblSSN";
            this.lblSSN.Size = new System.Drawing.Size(159, 17);
            this.lblSSN.TabIndex = 131;
            this.lblSSN.Text = "Social Security Number:";
            // 
            // lblEmployID
            // 
            this.lblEmployID.AutoSize = true;
            this.lblEmployID.Location = new System.Drawing.Point(12, 54);
            this.lblEmployID.Name = "lblEmployID";
            this.lblEmployID.Size = new System.Drawing.Size(53, 17);
            this.lblEmployID.TabIndex = 108;
            this.lblEmployID.Text = "EmpID:";
            // 
            // txtEmployID
            // 
            this.txtEmployID.Location = new System.Drawing.Point(140, 54);
            this.txtEmployID.Name = "txtEmployID";
            this.txtEmployID.Size = new System.Drawing.Size(100, 22);
            this.txtEmployID.TabIndex = 107;
            this.txtEmployID.TextChanged += new System.EventHandler(this.txtEmployID_TextChanged);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(188, 378);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(90, 46);
            this.btnDelete.TabIndex = 169;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            // 
            // btnUpDate
            // 
            this.btnUpDate.Location = new System.Drawing.Point(105, 378);
            this.btnUpDate.Name = "btnUpDate";
            this.btnUpDate.Size = new System.Drawing.Size(90, 46);
            this.btnUpDate.TabIndex = 168;
            this.btnUpDate.Text = "Update";
            this.btnUpDate.UseVisualStyleBackColor = true;
            // 
            // btnReturn
            // 
            this.btnReturn.Location = new System.Drawing.Point(399, 378);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Size = new System.Drawing.Size(112, 46);
            this.btnReturn.TabIndex = 167;
            this.btnReturn.Text = "Return To menu";
            this.btnReturn.UseVisualStyleBackColor = true;
            // 
            // btnSubmit
            // 
            this.btnSubmit.Location = new System.Drawing.Point(9, 378);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(90, 46);
            this.btnSubmit.TabIndex = 166;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnWform
            // 
            this.btnWform.Location = new System.Drawing.Point(284, 378);
            this.btnWform.Name = "btnWform";
            this.btnWform.Size = new System.Drawing.Size(109, 46);
            this.btnWform.TabIndex = 170;
            this.btnWform.Text = "W-4 Form";
            this.btnWform.UseVisualStyleBackColor = true;
            // 
            // ssnTextbox
            // 
            this.ssnTextbox.Location = new System.Drawing.Point(176, 294);
            this.ssnTextbox.Mask = "000-00-0000";
            this.ssnTextbox.Name = "ssnTextbox";
            this.ssnTextbox.Size = new System.Drawing.Size(102, 22);
            this.ssnTextbox.TabIndex = 177;
            // 
            // lblBankN
            // 
            this.lblBankN.AutoSize = true;
            this.lblBankN.Location = new System.Drawing.Point(12, 327);
            this.lblBankN.Name = "lblBankN";
            this.lblBankN.Size = new System.Drawing.Size(85, 17);
            this.lblBankN.TabIndex = 181;
            this.lblBankN.Text = "Bank Name:";
            // 
            // bankNText
            // 
            this.bankNText.Location = new System.Drawing.Point(140, 322);
            this.bankNText.Name = "bankNText";
            this.bankNText.Size = new System.Drawing.Size(149, 22);
            this.bankNText.TabIndex = 180;
            this.bankNText.TextChanged += new System.EventHandler(this.bankNText_TextChanged);
            // 
            // lblBankName
            // 
            this.lblBankName.AutoSize = true;
            this.lblBankName.Location = new System.Drawing.Point(300, 327);
            this.lblBankName.Name = "lblBankName";
            this.lblBankName.Size = new System.Drawing.Size(105, 17);
            this.lblBankName.TabIndex = 179;
            this.lblBankName.Text = "Bank Routing#:";
            // 
            // bankroutingText
            // 
            this.bankroutingText.Location = new System.Drawing.Point(428, 327);
            this.bankroutingText.Name = "bankroutingText";
            this.bankroutingText.Size = new System.Drawing.Size(145, 22);
            this.bankroutingText.TabIndex = 178;
            this.bankroutingText.TextChanged += new System.EventHandler(this.bankroutingText_TextChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Payroll.Properties.Resources.polarxpress;
            this.ClientSize = new System.Drawing.Size(708, 426);
            this.Controls.Add(this.lblBankN);
            this.Controls.Add(this.bankNText);
            this.Controls.Add(this.lblBankName);
            this.Controls.Add(this.bankroutingText);
            this.Controls.Add(this.ssnTextbox);
            this.Controls.Add(this.btnWform);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnUpDate);
            this.Controls.Add(this.btnReturn);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.lblHourlyP);
            this.Controls.Add(this.hourlypayText);
            this.Controls.Add(this.stateTextBox);
            this.Controls.Add(this.HphoneTextBox);
            this.Controls.Add(this.maskedTextBox3);
            this.Controls.Add(this.zipCodeTextBox);
            this.Controls.Add(this.phoneTextBox);
            this.Controls.Add(this.lblState);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.lblBAN);
            this.Controls.Add(this.bankaccnText);
            this.Controls.Add(this.lblSSN);
            this.Controls.Add(this.lblCellP);
            this.Controls.Add(this.lblEmail);
            this.Controls.Add(this.lblHomeP);
            this.Controls.Add(this.emailText);
            this.Controls.Add(this.lblZip);
            this.Controls.Add(this.lblCity);
            this.Controls.Add(this.cityTextBox);
            this.Controls.Add(this.lblAddress);
            this.Controls.Add(this.addressTextBox);
            this.Controls.Add(this.labelLastName);
            this.Controls.Add(this.lastNameTextBox);
            this.Controls.Add(this.lblBirthD);
            this.Controls.Add(this.lblFirstName);
            this.Controls.Add(this.firstNameTextBox);
            this.Controls.Add(this.lblEmployID);
            this.Controls.Add(this.txtEmployID);
            this.Controls.Add(this.lblStudentG);
            this.Name = "Form1";
            this.Text = "Employee";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ComboBox stateTextBox;
        private System.Windows.Forms.MaskedTextBox HphoneTextBox;
        private System.Windows.Forms.MaskedTextBox maskedTextBox3;
        private System.Windows.Forms.MaskedTextBox zipCodeTextBox;
        private System.Windows.Forms.MaskedTextBox phoneTextBox;
        private System.Windows.Forms.Label lblState;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label lblBAN;
        private System.Windows.Forms.TextBox bankaccnText;
        private System.Windows.Forms.Label lblCellP;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.Label lblHomeP;
        private System.Windows.Forms.TextBox emailText;
        private System.Windows.Forms.Label lblZip;
        private System.Windows.Forms.Label lblCity;
        private System.Windows.Forms.TextBox cityTextBox;
        private System.Windows.Forms.Label lblAddress;
        private System.Windows.Forms.TextBox addressTextBox;
        private System.Windows.Forms.Label labelLastName;
        private System.Windows.Forms.TextBox lastNameTextBox;
        private System.Windows.Forms.Label lblBirthD;
        private System.Windows.Forms.Label lblFirstName;
        private System.Windows.Forms.TextBox firstNameTextBox;
        private System.Windows.Forms.Label lblStudentG;
        private System.Windows.Forms.Label lblHourlyP;
        private System.Windows.Forms.TextBox hourlypayText;
        private System.Windows.Forms.Label lblSSN;
        private System.Windows.Forms.Label lblEmployID;
        private System.Windows.Forms.TextBox txtEmployID;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnUpDate;
        private System.Windows.Forms.Button btnReturn;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.Button btnWform;
        private System.Windows.Forms.MaskedTextBox ssnTextbox;
        private System.Windows.Forms.Label lblBankN;
        private System.Windows.Forms.TextBox bankNText;
        private System.Windows.Forms.Label lblBankName;
        private System.Windows.Forms.TextBox bankroutingText;
    }
}

